<template>


    <section tabindex="-1" class="relative max-w-7xl mx-auto px-4 focus:outline-none sm:px-3 md:px-5">
        <div class="grid grid-cols-6 gap-6 lg:gap-8 sm:grid-cols-2 lg:grid-cols-3">
            <ul class="space-y-8">
                <li class="text-sm leading-6">
                    <figure
                        class="relative flex flex-col-reverse bg-slate-50 rounded-lg p-6 dark:bg-slate-800 dark:highlight-white/5">
                        <blockquote class="mt-6 text-slate-700 dark:text-slate-300 font-semibold text-gray-900 text-lg">
                            <svg width="45" height="36" class="mb-5 fill-current text-cyan-100">
                                <path
                                    d="M13.415.001C6.07 5.185.887 13.681.887 23.041c0 7.632 4.608 12.096 9.936 12.096 5.04 0 8.784-4.032 8.784-8.784 0-4.752-3.312-8.208-7.632-8.208-.864 0-2.016.144-2.304.288.72-4.896 5.328-10.656 9.936-13.536L13.415.001zm24.768 0c-7.2 5.184-12.384 13.68-12.384 23.04 0 7.632 4.608 12.096 9.936 12.096 4.896 0 8.784-4.032 8.784-8.784 0-4.752-3.456-8.208-7.776-8.208-.864 0-1.872.144-2.16.288.72-4.896 5.184-10.656 9.792-13.536L38.183.001z">
                                </path>
                            </svg>
                            <p>I feel like an idiot for not using Tailwind CSS until now.</p>
                        </blockquote>
                        <figcaption class="flex items-center space-x-4"><img
                                src="/_next/static/media/ryan-florence.34fb7796afb30db4ae598b06a00cbee3.jpg" alt=""
                                class="flex-none w-14 h-14 rounded-full object-cover" loading="lazy">
                            <div class="flex-auto">
                                <div class="text-base text-slate-900 font-semibold dark:text-slate-300"><a
                                        href="https://twitter.com/ryanflorence/status/1187951799442886656"
                                        tabindex="0"><span class="absolute inset-0"></span>Ryan Florence</a></div>
                                <div class="mt-0.5">Remix &amp; React Training</div>
                            </div>
                        </figcaption>
                    </figure>
                </li>
                <li class="text-sm leading-6">
                    <figure
                        class="relative flex flex-col-reverse bg-slate-50 rounded-lg p-6 dark:bg-slate-800 dark:highlight-white/5">
                        <blockquote class="mt-6 text-slate-700 dark:text-slate-300">
                            <p>I feel like an idiot for not using Tailwind CSS until now.</p>
                        </blockquote>
                        <figcaption class="flex items-center space-x-4"><img
                                src="/_next/static/media/ryan-florence.34fb7796afb30db4ae598b06a00cbee3.jpg" alt=""
                                class="flex-none w-14 h-14 rounded-full object-cover" loading="lazy">
                            <div class="flex-auto">
                                <div class="text-base text-slate-900 font-semibold dark:text-slate-300"><a
                                        href="https://twitter.com/ryanflorence/status/1187951799442886656"
                                        tabindex="0"><span class="absolute inset-0"></span>Ryan Florence</a></div>
                                <div class="mt-0.5">Remix &amp; React Training</div>
                            </div>
                        </figcaption>
                    </figure>
                </li>

            </ul>


        </div>

    </section>

   


</template>